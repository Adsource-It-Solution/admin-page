{
    "data": [
        {
            "title": "3-day monthly top-up bonus up to 5%",
            "siteMessage": "<p>🎰🎰Click to enter the channel to receive daily red envelope rewards🎁🎁</p><p><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">🧧🧧🧧Channel link:❤️💚💰❤️💚</span></p><p><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">👉👉</span><a href="https://t.me/SIKKIMCLUBWIN" target="_blank" style="background-color: rgb(255, 255, 255); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">https://t.me/Sikkim3</a><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">👈👈</span></p><p><br></p><p><img src="https://smartwinning.in/banner/Chart.jpg" style="width: 302.167px; height: 383.494px;"><br></p><p>🎰🎰Click to enter the channel to receive daily red envelope rewards🎁🎁</p><p><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">🧧🧧🧧Channel link:❤️💚💰❤️💚</span></p><p><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">👉👉</span><a href="https://t.me/SIKKIMCLUBWIN" target="_blank" style="background-color: rgb(255, 255, 255); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">https://t.me/Sikkim3</a><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">👈👈</span><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;"><br></span></p><p><br></p><p><br></p>",
            "sort": 0,
            "addtime": "2025-01-05 20:29:59"
        }
    ],
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "serviceNowTime": "2025-01-16 00:36:25"
}