{
    "data": null,
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "serviceNowTime": "2025-01-16 00:47:46"
}