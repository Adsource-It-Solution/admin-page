{
    "data": [
        {
            "vendorCode": "JILI",
            "sort": 90,
            "childList": [
                {
                    "gameID": "229",
                    "gameNameEn": "Mines",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/229.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "224",
                    "gameNameEn": "Go Rush",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/224.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "51",
                    "gameNameEn": "Money Coming",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/51.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "109",
                    "gameNameEn": "Fortune Gems",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/109.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "232",
                    "gameNameEn": "Tower",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/232.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "223",
                    "gameNameEn": "Fortune Gems 2",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/223.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "200",
                    "gameNameEn": "Pappu",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/200.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "32",
                    "gameNameEn": "Jack Pot Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/32.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "82",
                    "gameNameEn": "Happy Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JILI/82.png",
                    "vendorId": 18,
                    "vendorCode": "JILI",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "CQ9",
            "sort": 65,
            "childList": [
                {
                    "gameID": "19",
                    "gameNameEn": "Hot Spin",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/19.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "AT01",
                    "gameNameEn": "OneShotFishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/AT01.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "AT05",
                    "gameNameEn": "LuckyFishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/AT05.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "102",
                    "gameNameEn": "Fruity Carnival",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/102.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "10",
                    "gameNameEn": "Lucky Bats",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/10.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "108",
                    "gameNameEn": "Jump Higher Mobile",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/108.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "208",
                    "gameNameEn": "Money Tree",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/208.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "86",
                    "gameNameEn": "RunningToro",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/86.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "67",
                    "gameNameEn": "Golden Eggs",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/CQ9/67.png",
                    "vendorId": 2,
                    "vendorCode": "CQ9",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "JDB",
            "sort": 7,
            "childList": [
                {
                    "gameID": "9014",
                    "gameNameEn": "Mines",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/9014.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "9016",
                    "gameNameEn": "Goal",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/9016.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "9013",
                    "gameNameEn": "Galaxy Burst",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/9013.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "8020",
                    "gameNameEn": "Open Sesame",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/8020.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "14036",
                    "gameNameEn": "Super Niubi",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/14036.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "14027",
                    "gameNameEn": "Lucky Seven",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/14027.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "14045",
                    "gameNameEn": "Super Niubi Deluxe",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/14045.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "14051",
                    "gameNameEn": "Dragons Gate",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/14051.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "14065",
                    "gameNameEn": "Blossom Of Wealth",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/JDB/14065.png",
                    "vendorId": 6,
                    "vendorCode": "JDB",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "MG",
            "sort": 7,
            "childList": [
                {
                    "gameID": "SMG_wildfireWins",
                    "gameNameEn": "Wildfire Wins",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_wildfireWins.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_10000Wishes",
                    "gameNameEn": "10000 Wishes",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_10000Wishes.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_auroraWilds",
                    "gameNameEn": "Aurora Wilds",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_auroraWilds.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_25000Talons",
                    "gameNameEn": "25000 Talons",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_25000Talons.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_4DiamondBlues",
                    "gameNameEn": "4 Diamond Blues™ - Megaways™",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_4DiamondBlues.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_cashNRichesMegaways",
                    "gameNameEn": "Cash 'N Riches Megaways™",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_cashNRichesMegaways.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_amazingLinkZeus",
                    "gameNameEn": "Amazing Link Zeus",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_amazingLinkZeus.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_aztecFalls",
                    "gameNameEn": "Aztec Falls",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_aztecFalls.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_megaMoneyMultiplier",
                    "gameNameEn": "Mega Money Multiplier",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG/SMG_megaMoneyMultiplier.png",
                    "vendorId": 4,
                    "vendorCode": "MG",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "EVO_Electronic",
            "sort": 1,
            "childList": [
                {
                    "gameID": "777strike0000000",
                    "gameNameEn": "777 Strike",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/777strike0000000.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "cupcakesf1000000",
                    "gameNameEn": "Cupcakes",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/cupcakesf1000000.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "frenchroulettene",
                    "gameNameEn": "NetEnt French Roulette",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/frenchroulettene.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "grandwheel000000",
                    "gameNameEn": "Grand Wheel",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/grandwheel000000.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "fortunehouse0000",
                    "gameNameEn": "Fortune House",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/fortunehouse0000.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "10001nights00000",
                    "gameNameEn": "10001 Nights",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/10001nights00000.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "fivestar00000000",
                    "gameNameEn": "Five Star",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/fivestar00000000.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "777superstrike00",
                    "gameNameEn": "777 Super Strike",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/777superstrike00.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "wildhotchilliree",
                    "gameNameEn": "Wild Hot Chilli Reels",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Electronic/wildhotchilliree.png",
                    "vendorId": 17,
                    "vendorCode": "EVO_Electronic",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "G9",
            "sort": 1,
            "childList": [
                {
                    "gameID": "777res",
                    "gameNameEn": "Fruit 777",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/777res.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "CardSlots",
                    "gameNameEn": "Card slot",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/CardSlots.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "GoldRushMaster",
                    "gameNameEn": "Gold rush",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/GoldRushMaster.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "slots-777Diamonds",
                    "gameNameEn": "Double Diamonds",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/slots-777Diamonds.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "slots-AgeofSteam",
                    "gameNameEn": "Age of Steam",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/slots-AgeofSteam.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "slots-Aladdin",
                    "gameNameEn": "Aladdin lamp",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/slots-Aladdin.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "slots-AngryOlympusplus",
                    "gameNameEn": "King Of The Gods",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/slots-AngryOlympusplus.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "slots-Athena",
                    "gameNameEn": "Athena Gold",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/slots-Athena.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "slots-BeerFestival",
                    "gameNameEn": "Beer Fortune",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/G9/slots-BeerFestival.png",
                    "vendorId": 41,
                    "vendorCode": "G9",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "PG",
            "sort": 1,
            "childList": [
                {
                    "gameID": "42",
                    "gameNameEn": "Ganesha Gold",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/42.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "127",
                    "gameNameEn": "Speed Winner",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/127.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "57",
                    "gameNameEn": "Dragon Hatch",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/57.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "40",
                    "gameNameEn": "Jungle Delight",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/40.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "135",
                    "gameNameEn": "Wild Bounty Showdown",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/135.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "68",
                    "gameNameEn": "Fortune Mouse",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/68.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "98",
                    "gameNameEn": "Fortune Ox",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/98.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "87",
                    "gameNameEn": "Treasures of Aztec",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/87.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "75",
                    "gameNameEn": "Ganesha Fortune",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/PG/75.png",
                    "vendorId": 5,
                    "vendorCode": "PG",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "MG_Fish",
            "sort": 0,
            "childList": [
                {
                    "gameID": "SFG_WDFuWaFishing",
                    "gameNameEn": "WD FuWa Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Fish/SFG_WDFuWaFishing.png",
                    "vendorId": 37,
                    "vendorCode": "MG_Fish",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SFG_WDMerryIslandFishing",
                    "gameNameEn": "WD Merry Island Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Fish/SFG_WDMerryIslandFishing.png",
                    "vendorId": 37,
                    "vendorCode": "MG_Fish",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SFG_WDGoldenTyrantFishing",
                    "gameNameEn": "WD Golden Tyrant Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Fish/SFG_WDGoldenTyrantFishing.png",
                    "vendorId": 37,
                    "vendorCode": "MG_Fish",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SFG_WDGoldBlastFishing",
                    "gameNameEn": "WD Gold Blast Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Fish/SFG_WDGoldBlastFishing.png",
                    "vendorId": 37,
                    "vendorCode": "MG_Fish",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SFG_WDGoldenFortuneFishing",
                    "gameNameEn": "WD Golden Fortune Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Fish/SFG_WDGoldenFortuneFishing.png",
                    "vendorId": 37,
                    "vendorCode": "MG_Fish",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SFG_WDGoldenFuwaFishing",
                    "gameNameEn": "WD Golden Fuwa Fishing",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Fish/SFG_WDGoldenFuwaFishing.png",
                    "vendorId": 37,
                    "vendorCode": "MG_Fish",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        }
    ],
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "serviceNowTime": "2025-01-16 00:36:25"
}