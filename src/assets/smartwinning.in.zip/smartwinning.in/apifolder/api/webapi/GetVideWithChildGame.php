{
    "data": [
        {
            "vendorCode": "EVO_Video",
            "sort": 75,
            "childList": [
                {
                    "gameID": "o735cjzyaeasv4o6",
                    "gameNameEn": "Blackjack VIP 3",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/o735cjzyaeasv4o6.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "olbibp3fylzaxvhb",
                    "gameNameEn": "Salon Privé Blackjack B",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/olbibp3fylzaxvhb.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "o735fhvsaeaswamh",
                    "gameNameEn": "Blackjack VIP 6",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/o735fhvsaeaswamh.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "o735ggd5iwsswcz7",
                    "gameNameEn": "Blackjack VIP 7",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/o735ggd5iwsswcz7.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "o735hfcqauecwjxp",
                    "gameNameEn": "Blackjack VIP 8",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/o735hfcqauecwjxp.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "o735di2eiwssv7eu",
                    "gameNameEn": "Blackjack VIP 4",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/o735di2eiwssv7eu.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "o735efxfaeasv666",
                    "gameNameEn": "Blackjack VIP 5",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/o735efxfaeasv666.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "olbinkuoylzayeoj",
                    "gameNameEn": "Salon Privé Blackjack D",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/olbinkuoylzayeoj.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "pdk52e3rey6upyie",
                    "gameNameEn": "Blackjack VIP 13",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/EVO_Video/pdk52e3rey6upyie.png",
                    "vendorId": 16,
                    "vendorCode": "EVO_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "DG",
            "sort": 7,
            "childList": [
                {
                    "gameID": "1_3",
                    "gameNameEn": "DragonTiger",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_3.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_11",
                    "gameNameEn": "Three Cards",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_11.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_14",
                    "gameNameEn": "Sedie",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_14.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_2",
                    "gameNameEn": "InBaccarat",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_2.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_16",
                    "gameNameEn": "Three Face",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_16.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_1",
                    "gameNameEn": "Baccarat",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_1.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_15",
                    "gameNameEn": "Fish, shrimp and crab",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_15.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_12",
                    "gameNameEn": "Quickness Sicbo",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_12.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "1_4",
                    "gameNameEn": "Roulette",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/DG/1_4.png",
                    "vendorId": 7,
                    "vendorCode": "DG",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "SEXY_Video",
            "sort": 1,
            "childList": [
                {
                    "gameID": "MX-LIVE-006",
                    "gameNameEn": "DragonTiger",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-006.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-003",
                    "gameNameEn": "Baccarat Insurance",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-003.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-001",
                    "gameNameEn": "Baccarat Classic",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-001.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-002",
                    "gameNameEn": "Baccarat",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-002.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-007",
                    "gameNameEn": "SicBo",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-007.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-009",
                    "gameNameEn": "Roulette",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-009.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-010",
                    "gameNameEn": "Red Blue Duel",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-010.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-012",
                    "gameNameEn": "Extra Andar Bahar",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-012.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "MX-LIVE-014",
                    "gameNameEn": "Thai Hi Lo",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/SEXY_Video/MX-LIVE-014.png",
                    "vendorId": 27,
                    "vendorCode": "SEXY_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        },
        {
            "vendorCode": "MG_Video",
            "sort": 0,
            "childList": [
                {
                    "gameID": "SMG_titaniumLiveGames_Roulette",
                    "gameNameEn": "Roulette ",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_Roulette.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGames_MP_Baccarat",
                    "gameNameEn": "Baccarat",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_MP_Baccarat.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGames_Baccarat",
                    "gameNameEn": "Bonus Baccarat",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_Baccarat.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGames_BaccaratplayboyNC",
                    "gameNameEn": "Baccarat - Playboy (NC)",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_BaccaratplayboyNC.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGames_BaccaratNC",
                    "gameNameEn": "No Commission Baccarat",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_BaccaratNC.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGames_Baccarat_Playboy",
                    "gameNameEn": "Baccarat - Playboy",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_Baccarat_Playboy.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGames_Roulette_Playboy",
                    "gameNameEn": "Roulette - Playboy",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_Roulette_Playboy.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGames_Sicbo",
                    "gameNameEn": "Sicbo",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGames_Sicbo.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                },
                {
                    "gameID": "SMG_titaniumLiveGamesAutoRoulette",
                    "gameNameEn": "Auto Roulette ",
                    "img": "https://ossimg.yuk87k786d.com/sikkim/gamelogo/MG_Video/SMG_titaniumLiveGamesAutoRoulette.png",
                    "vendorId": 38,
                    "vendorCode": "MG_Video",
                    "imgUrl2": null,
                    "customGameType": 0
                }
            ]
        }
    ],
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "serviceNowTime": "2025-01-16 00:33:33"
}