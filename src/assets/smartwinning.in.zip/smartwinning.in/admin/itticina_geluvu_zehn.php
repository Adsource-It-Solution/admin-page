<?php
include("conn.php");
error_reporting(E_ALL);
ini_set('display_errors', 1);

$log_file = "debug.log";
file_put_contents($log_file, "\n--- NEW REQUEST ---\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = trim($_POST['username']);
    file_put_contents($log_file, "Received input: $username\n", FILE_APPEND);

    // ✅ Validate input (Only numbers 0-9)
    if (!is_numeric($username) || $username < 0 || $username > 9) {
        file_put_contents($log_file, "Invalid Input Detected!\n", FILE_APPEND);
        die('<h1 style="text-align: center; color: red;">Invalid Input!</h1>');
    }

    // ✅ Sanitize input
    $username = $conn->real_escape_string($username);
    file_put_contents($log_file, "Sanitized input: $username\n", FILE_APPEND);

    // ✅ Start transaction to prevent inconsistencies
    $conn->begin_transaction(MYSQLI_TRANS_START_READ_WRITE);

    // ✅ Lock the table to prevent other updates while we process
    $conn->query("LOCK TABLES hastacalita_phalitansa_funf WRITE, hastacalita_phalitansa_zehn WRITE");

    // ✅ Reset previous predictions
    $resetQuery = "UPDATE hastacalita_phalitansa_funf SET sthiti='0'";
    if (!$conn->query($resetQuery)) {
        $conn->rollback();
        $conn->query("UNLOCK TABLES");
        file_put_contents($log_file, "Error resetting previous predictions: " . $conn->error . "\n", FILE_APPEND);
        die('<h1 style="text-align: center; color: red;">Error resetting previous predictions! ' . $conn->error . '</h1>');
    }
    file_put_contents($log_file, "Previous predictions reset.\n", FILE_APPEND);

    // ✅ Update new prediction
    $updateQuery = "UPDATE hastacalita_phalitansa_zehn SET sthiti='1' WHERE sankhye='$username'";
    if (!$conn->query($updateQuery)) {
        $conn->rollback();
        $conn->query("UNLOCK TABLES");
        file_put_contents($log_file, "Prediction Update Failed: " . $conn->error . "\n", FILE_APPEND);
        die('<h1 style="text-align: center; color: red;">Prediction Update Failed! ' . $conn->error . '</h1>');
    }
    file_put_contents($log_file, "Prediction updated successfully for number: $username\n", FILE_APPEND);

    // ✅ Commit transaction and unlock tables
    $conn->commit();
    $conn->query("UNLOCK TABLES");

    // ✅ Double-check the update by fetching the active number
    sleep(1); // Small delay to ensure DB updates properly
    $verifyQuery = "SELECT sankhye FROM hastacalita_phalitansa_zehn WHERE sthiti='1'";
    $result = $conn->query($verifyQuery);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        file_put_contents($log_file, "Verified Active Prediction: " . $row['sankhye'] . "\n", FILE_APPEND);
        echo "<h2 style='text-align: center; color: green;'>Final Active Prediction: " . htmlspecialchars($row['sankhye']) . "</h2>";
    } else {
        file_put_contents($log_file, "Verification Failed - No active prediction found!\n", FILE_APPEND);
        echo "<h2 style='text-align: center; color: red;'>No Active Prediction Found!</h2>";
    }

    // ✅ Redirect after showing result
    header("Refresh: 3; URL=wingo10min.php");
    exit();
} else {
    file_put_contents($log_file, "No POST request received!\n", FILE_APPEND);
    die('<h1 style="text-align: center; color: red;">No POST request received!</h1>');
}
?>
