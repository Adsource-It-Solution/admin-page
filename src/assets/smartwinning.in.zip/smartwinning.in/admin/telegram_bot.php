<?php
include("conn.php");  // Database connection

$botToken = "7404957627:AAE4YMTuzHSzdDR_JIsUsHprN7KEZJujlG0";  
$chatId = "@autoprediction";  

// Fetch the latest Period ID
$query = "SELECT atadaaidi FROM gelluonduhogu_drei ORDER BY kramasankhye DESC LIMIT 1";
$result = $conn->query($query);
$periodData = mysqli_fetch_assoc($result);
$periodId = $periodData['atadaaidi'] ?? "Not Found";

// Investment multipliers (1x to 10x)
$investmentMultipliers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
$investment = $investmentMultipliers[array_rand($investmentMultipliers)] * 100; // Convert to amount

// Randomly select Red or Green as prediction
$prediction = (rand(0, 1) == 0) ? "🟥 *Red*" : "🟩 *Green*";

// Construct message with ONLY prediction & investment
$message = "🎯 *WinGo Prediction*\n"
         . "📅 *Period:* $periodId\n"
         . "🔮 *Prediction:* $prediction\n"
         . "💰 *Investment:* ${investment}₹\n";

// Send to Telegram
$message = urlencode($message);
$url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=$message&parse_mode=Markdown";
$response = file_get_contents($url);

if ($response) {
    echo "Message sent successfully!";
} else {
    echo "Failed to send message!";
}
?>
