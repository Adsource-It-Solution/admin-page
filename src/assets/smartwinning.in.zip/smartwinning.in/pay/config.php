<?php
return [
    'db_host' => 'localhost',       
    'db_user' => 'smar524_smartwin',  
    'db_pass' => 'smar524_smartwin',  
    'db_name' => 'smar524_smartwin',
    'api_url' => 'https://www.lg-pay.com/api/order/create',
    'secret_key' => '9fPZhG2RpSnuUPNM',
    'app_id' => 'YD3405',
    'name' => 'smartwinning.in',
];
