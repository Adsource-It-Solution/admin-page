<?php
	$conn = mysqli_connect('localhost', 'smar524_smartwin', 'smar524_smartwin', 'smar524_smartwin');
	
	if (!$conn) {
		echo "Error: " . mysqli_connect_error();
		exit();
	}
	
	date_default_timezone_set("Asia/Kolkata"); 
?>